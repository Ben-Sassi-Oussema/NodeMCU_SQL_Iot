<?php
   	include("connect.php");
   	
   	$link=Connection();

	$temp1=$_GET["temp1"];
	

	$query = "INSERT INTO `temps` (`temp_c`, `temp_date`) 
		VALUES ('".$temp1."','".date('Y-m-d H:i:s')."')"; 
   	
   if ($link->query($query) === TRUE) {
      echo "New record created successfully";
   } else {
      echo "Error: " . $query . "<br>" . $link->error;
   }

   $link->close();

?>
