<?php

	function Connection(){
		$server="localhost";
		$user="root";
		$pass="";
		$db="arduino";
	   	
		$connection = new mysqli($server, $user, $pass,$db);

		if (!$connection) {
	    	die('MySQL ERROR: ' . $connection->error);
		}
		

		return $connection;
	}
?>
