$(document).ready(function(){
	$.ajax({
		url : "http://localhost/chartjs/followersdata.php",
		type : "GET",
		success : function(data){
			console.log(data);

			var temp_date_ok = [];
			var temp_c_ok = [];

			for(var i in data) {

				temp_date_ok.push(data[i].temp_date);
				temp_c_ok.push(data[i].temp_c);
			}

			var chartdata = {
				labels: temp_date_ok,
				datasets: [
					{
						label: "Temperature",
						fill: false,
						lineTension: 0.1,
						backgroundColor: "rgba(59, 89, 152, 0.75)",
						borderColor: "rgba(59, 89, 152, 1)",
						pointHoverBackgroundColor: "rgba(59, 89, 152, 1)",
						pointHoverBorderColor: "rgba(59, 89, 152, 1)",
						data: temp_c_ok
					}
				]
			};

			var ctx = $("#mycanvas");

			var LineGraph = new Chart(ctx, {
				type: 'line',
				data: chartdata
				options: {
					scales: {
						yAxes: [{
							ticks: {
								suggestedMin: 0
                    			suggestedMax: 100
							}
						}]
					}
				}
				
           		}
			});
			
		},
		error : function(data) {

		}

	});
});